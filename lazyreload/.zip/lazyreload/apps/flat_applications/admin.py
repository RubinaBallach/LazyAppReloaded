from django.contrib import admin
#from .models import LazyRenter, Landlord
# Register your models here.

# admin.register(LazyRenter)
# admin.register(Landlord)
