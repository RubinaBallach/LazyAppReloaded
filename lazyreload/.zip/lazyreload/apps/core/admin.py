from django.contrib import admin
#from .models import AiSettings
# Register your models here.

#admin.register(AiSettings)